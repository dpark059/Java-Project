/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bodymassindex;

import java.text.DecimalFormat;
import java.util.Scanner;

public class BodyMassIndex {

   public static Person anyPerson;
  
   public static void main(String[] args) {
       createPersonObject();
       displayBMI();
   }

   public static void createPersonObject() {
       String firstName;
       String lastName;
       double hightInches;
       double weightPounds;
      
       Scanner sc=new Scanner(System.in);
       System.out.println("What is your First Name?");
       firstName=sc.next();
       System.out.println("What is your Last Name?");
       lastName=sc.next();
       System.out.println("How much do you Weigh (in pounds)?");
       weightPounds=sc.nextDouble();
       System.out.println("How tall are you (in inches)?");
       hightInches=sc.nextDouble();
      
       anyPerson =new Person(firstName, lastName, hightInches, weightPounds);
      
   }
   public static void displayBMI() {
       DecimalFormat df = new DecimalFormat("#0.00");
       anyPerson.calculateBMI();
       String msg = "You are considered ";
      
       if(anyPerson.getBmi() < 18.5) {
           msg += "Underweight";
       } else if(anyPerson.getBmi() >= 18.5 && anyPerson.getBmi() <= 24.9) {
           msg += "Healthy";
       } else if(anyPerson.getBmi() >= 25 && anyPerson.getBmi() <= 29.9) {
           msg += "Overweight";
       } else if(anyPerson.getBmi() >= 30 && anyPerson.getBmi() <= 39.9) {
           msg += "Obese";
       } else if(anyPerson.getBmi() > 39.9) {
           msg += "Extremely Obese";
       }
      
       System.out.println(anyPerson.toString());
       System.out.println("Your BMI is "+df.format(anyPerson.getBmi()));
       System.out.println(msg);
      
   }
}
