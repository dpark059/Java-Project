/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bodymassindex;

/**
 *
 * @author AH0165328
 */
public class Person {

   private String firstName;
   private String lastName;
   private double hightInches;
   private double weightPounds;
   private double bmi;
  
   public Person(String firstName, String lastName, double hightInches, double weightPounds) {
      
       this.firstName = firstName;
       this.lastName = lastName;
       this.hightInches = hightInches;
       this.weightPounds = weightPounds;
      
   }

   public String getFirstName() {
       return firstName;
   }

   public void setFirstName(String firstName) {
       this.firstName = firstName;
   }

   public String getLastName() {
       return lastName;
   }

   public void setLastName(String lastName) {
       this.lastName = lastName;
   }

   public double getHightInches() {
       return hightInches;
   }

   public void setHightInches(double hightInches) {
       this.hightInches = hightInches;
   }

   public double getWeightPounds() {
       return weightPounds;
   }

   public void setWeightPounds(double weightPounds) {
       this.weightPounds = weightPounds;
   }

   public double getBmi() {
       return bmi;
   }

   public void setBmi(double bmi) {
       this.bmi = bmi;
   }

   @Override
   public String toString() {
       return firstName + " "+ lastName + " weighs " + weightPounds
               + " and measures " + hightInches + " tall";
   }
  
   public void calculateBMI() {
       double calculatedBMI = (this.weightPounds/(this.hightInches * this.hightInches)) * 703;
       this.setBmi(calculatedBMI);
   }

}